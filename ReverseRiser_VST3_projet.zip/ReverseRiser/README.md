# Reverse Riser (VST3)

Instrument VST3 : charge un sample, fabrique un riser inverse (reverb + delay de la 1re seconde),
puis joue "riser + sample" quand il recoit une note MIDI.

## Compiler (Windows)
1. Installer Visual Studio 2022 Community (charge de travail "Developpement Desktop en C++"), CMake et Git.
2. Dans un terminal, dans ce dossier :
       cmake -B build -G "Visual Studio 17 2022"
       cmake --build build --config Release
   (la 1re fois, JUCE est telecharge automatiquement : il faut internet, quelques minutes)
3. Le plugin est dans :
       build\ReverseRiser_artefacts\Release\VST3\Reverse Riser.vst3
   Copie ce dossier dans  C:\Program Files\Common Files\VST3\

## Compiler (Mac)
       cmake -B build -G Xcode
       cmake --build build --config Release
   Copie le .vst3 dans ~/Library/Audio/Plug-Ins/VST3/

## Dans FL Studio
Options > Manage plugins > "Find installed plugins" (Start scan), puis ajoute "Reverse Riser" comme generateur.
Glisse un WAV dans la fenetre du plugin, puis place une note dans le piano roll : la note declenche le riser,
puis le sample. Le bouton "Exporter riser" (ou le bloc a glisser) donne un WAV du riser SEUL, a poser avant ton sample dans la playlist.

## Reglages
Longueur 1-10 s | Reverb Room/Hall/Plate/Cathedral/Dark | Delay 0-100 % | Volume 10-150 % | Largeur 0-200 %
