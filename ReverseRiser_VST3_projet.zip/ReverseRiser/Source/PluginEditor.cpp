#include "PluginEditor.h"

ReverseRiserEditor::ReverseRiserEditor (ReverseRiserProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setSize (600, 360);

    fileLabel.setJustificationType (juce::Justification::centredLeft);
    statusLabel.setJustificationType (juce::Justification::centredLeft);
    statusLabel.setColour (juce::Label::textColourId, juce::Colours::lightgrey);
    addAndMakeVisible (fileLabel);
    addAndMakeVisible (statusLabel);

    loadButton.onClick = [this] { chooseFile(); };
    addAndMakeVisible (loadButton);

    exportButton.onClick = [this]
    {
        chooser = std::make_unique<juce::FileChooser> (
            "Exporter le riser",
            juce::File::getSpecialLocation (juce::File::userDesktopDirectory).getChildFile ("riser.wav"),
            "*.wav");
        chooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                                  | juce::FileBrowserComponent::warnAboutOverwriting,
                              [this] (const juce::FileChooser& fc)
                              {
                                  auto f = fc.getResult();
                                  if (f == juce::File()) return;
                                  if (! f.hasFileExtension ("wav")) f = f.withFileExtension ("wav");
                                  if (! proc.exportRendered (f))
                                      statusLabel.setText ("Export impossible (charge d'abord un WAV)", juce::dontSendNotification);
                              });
    };
    addAndMakeVisible (exportButton);

    dragHandle.makeFile = [this] { return proc.exportToTemp(); };
    addAndMakeVisible (dragHandle);

    setupKnob (lengthKnob, "length", "Longueur", " s", 1);
    setupKnob (delayKnob,  "delay",  "Delay",    " %", 0);
    setupKnob (volumeKnob, "volume", "Volume",   " %", 0);
    setupKnob (widthKnob,  "width",  "Largeur",  " %", 0);

    reverbLabel.setText ("Reverb", juce::dontSendNotification);
    reverbLabel.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (reverbLabel);
    reverbBox.addItemList (juce::StringArray { "Room", "Hall", "Plate", "Cathedral", "Dark" }, 1);
    addAndMakeVisible (reverbBox);
    reverbAtt = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (proc.apvts, "reverb", reverbBox);

    startTimerHz (10);
    timerCallback();
}

ReverseRiserEditor::~ReverseRiserEditor()
{
    stopTimer();
}

void ReverseRiserEditor::setupKnob (Knob& k, const juce::String& id, const juce::String& name,
                                    const juce::String& suffix, int decimals)
{
    k.slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    k.slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 80, 20);
    k.slider.setTextValueSuffix (suffix);
    k.slider.setNumDecimalPlacesToDisplay (decimals);
    k.label.setText (name, juce::dontSendNotification);
    k.label.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (k.slider);
    addAndMakeVisible (k.label);
    k.att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, id, k.slider);
}

void ReverseRiserEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1e242b));
    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (20.0f, juce::Font::bold));
    g.drawText ("REVERSE RISER", getLocalBounds().removeFromTop (30).reduced (16, 0),
                juce::Justification::centredRight);
}

void ReverseRiserEditor::resized()
{
    auto r = getLocalBounds().reduced (16);
    auto top = r.removeFromTop (30);
    loadButton.setBounds (top.removeFromLeft (140));
    top.removeFromLeft (10);
    fileLabel.setBounds (top.removeFromLeft (260));

    r.removeFromTop (6);
    statusLabel.setBounds (r.removeFromTop (22));

    auto bottom = r.removeFromBottom (40);
    exportButton.setBounds (bottom.removeFromLeft (150));
    bottom.removeFromLeft (10);
    dragHandle.setBounds (bottom);

    r.removeFromTop (10);
    r.removeFromBottom (10);

    const int colW = r.getWidth() / 5;
    auto place = [&] (juce::Label& lab, juce::Component& comp, juce::Rectangle<int> col)
    {
        lab.setBounds (col.removeFromTop (22));
        comp.setBounds (col);
    };

    place (lengthKnob.label, lengthKnob.slider, r.removeFromLeft (colW));

    auto comboCol = r.removeFromLeft (colW);
    reverbLabel.setBounds (comboCol.removeFromTop (22));
    reverbBox.setBounds (comboCol.withSizeKeepingCentre (colW - 16, 28));

    place (delayKnob.label,  delayKnob.slider,  r.removeFromLeft (colW));
    place (volumeKnob.label, volumeKnob.slider, r.removeFromLeft (colW));
    place (widthKnob.label,  widthKnob.slider,  r);
}

void ReverseRiserEditor::timerCallback()
{
    fileLabel.setText (proc.hasSample() ? proc.getSampleName() : "Aucun sample charge", juce::dontSendNotification);

    if (! proc.hasSample())
        statusLabel.setText ("Glisse un fichier WAV ici ou clique sur Charger", juce::dontSendNotification);
    else if (proc.isRendering())
        statusLabel.setText ("Calcul du riser...", juce::dontSendNotification);
    else
        statusLabel.setText ("Pret : joue une note MIDI pour ecouter riser + sample, ou glisse le riser seul", juce::dontSendNotification);
}

void ReverseRiserEditor::chooseFile()
{
    chooser = std::make_unique<juce::FileChooser> (
        "Choisis un sample", juce::File(), "*.wav;*.aif;*.aiff;*.flac;*.mp3;*.ogg");
    chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                          [this] (const juce::FileChooser& fc)
                          {
                              const auto f = fc.getResult();
                              if (f.existsAsFile() && ! proc.loadSample (f))
                                  statusLabel.setText ("Fichier illisible", juce::dontSendNotification);
                          });
}

bool ReverseRiserEditor::isInterestedInFileDrag (const juce::StringArray& files)
{
    for (auto& f : files)
        if (juce::File (f).hasFileExtension ("wav;aif;aiff;flac;mp3;ogg")) return true;
    return false;
}

void ReverseRiserEditor::filesDropped (const juce::StringArray& files, int, int)
{
    if (files.size() > 0 && ! proc.loadSample (juce::File (files[0])))
        statusLabel.setText ("Fichier illisible", juce::dontSendNotification);
}
