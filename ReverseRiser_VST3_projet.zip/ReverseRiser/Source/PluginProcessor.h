#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <atomic>
#include <memory>
#include "RiserEngine.h"

class ReverseRiserProcessor : public juce::AudioProcessor,
                              private juce::AudioProcessorValueTreeState::Listener
{
public:
    ReverseRiserProcessor();
    ~ReverseRiserProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Reverse Riser"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // --- fonctions pour l'interface ---
    bool loadSample (const juce::File& file);
    bool hasSample() const;
    juce::String getSampleName() const;
    bool exportRendered (const juce::File& destination);   // ecrit le riser seul en WAV 24 bits
    juce::File exportToTemp();                             // idem, dans le dossier temporaire
    bool isRendering() const { return rendering.load(); }

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void parameterChanged (const juce::String& parameterID, float newValue) override;
    void doRender();
    void renderRange (juce::AudioBuffer<float>& out, const juce::AudioBuffer<float>* src, int start, int end);

    struct RenderThread : public juce::Thread
    {
        explicit RenderThread (ReverseRiserProcessor& o) : juce::Thread ("RiserRender"), owner (o) {}
        void run() override
        {
            while (! threadShouldExit())
            {
                if (owner.dirty.exchange (false)) owner.doRender();
                else wait (40);
            }
        }
        ReverseRiserProcessor& owner;
    };

    // sample source (accessible depuis plusieurs threads)
    mutable juce::CriticalSection sourceLock;
    juce::AudioBuffer<float> sourceSample;
    double sourceRate = 44100.0;
    juce::String samplePath;

    // resultat du rendu (lu par le thread audio)
    juce::SpinLock renderedLock;
    std::shared_ptr<const juce::AudioBuffer<float>> rendered;
    int renderedRiserLen = 0;   // nombre d'echantillons du riser au debut du buffer rendu

    std::atomic<bool> dirty { false };
    std::atomic<bool> rendering { false };
    std::atomic<double> currentRate { 44100.0 };

    // etat de lecture (thread audio uniquement)
    bool playing = false;
    int playPos = 0;

    RenderThread renderThread { *this };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ReverseRiserProcessor)
};
