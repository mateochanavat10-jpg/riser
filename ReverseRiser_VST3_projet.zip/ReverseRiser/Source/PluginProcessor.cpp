#include "PluginProcessor.h"
#include "PluginEditor.h"

static const char* kParamIds[] = { "length", "reverb", "delay", "volume", "width" };

juce::AudioProcessorValueTreeState::ParameterLayout ReverseRiserProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "length", 1 }, "Riser Length",
        juce::NormalisableRange<float> (1.0f, 10.0f, 0.1f), 4.0f));

    layout.add (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "reverb", 1 }, "Reverb Type",
        juce::StringArray { "Room", "Hall", "Plate", "Cathedral", "Dark" }, 1));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "delay", 1 }, "Delay Amount",
        juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 40.0f));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "volume", 1 }, "Riser Volume",
        juce::NormalisableRange<float> (10.0f, 150.0f, 1.0f), 80.0f));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "width", 1 }, "Stereo Width",
        juce::NormalisableRange<float> (0.0f, 200.0f, 1.0f), 100.0f));

    return layout;
}

ReverseRiserProcessor::ReverseRiserProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    for (auto* id : kParamIds)
        apvts.addParameterListener (id, this);

    renderThread.startThread();
}

ReverseRiserProcessor::~ReverseRiserProcessor()
{
    renderThread.stopThread (5000);
    for (auto* id : kParamIds)
        apvts.removeParameterListener (id, this);
}

void ReverseRiserProcessor::parameterChanged (const juce::String&, float)
{
    dirty = true;
}

void ReverseRiserProcessor::prepareToPlay (double sampleRate, int)
{
    if (std::abs (currentRate.load() - sampleRate) > 1.0e-6)
    {
        currentRate = sampleRate;
        dirty = true;
    }
    playing = false;
    playPos = 0;
    if (hasSample()) dirty = true;
}

bool ReverseRiserProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

// ---------------------------------------------------------------- rendu

void ReverseRiserProcessor::doRender()
{
    juce::AudioBuffer<float> src;
    double srcRate = 44100.0;
    {
        const juce::ScopedLock sl (sourceLock);
        if (sourceSample.getNumSamples() == 0) return;
        src = sourceSample;
        srcRate = sourceRate;
    }

    riser::Settings s;
    s.lengthSec   = apvts.getRawParameterValue ("length")->load();
    s.reverbType  = (int) apvts.getRawParameterValue ("reverb")->load();
    s.delayAmount = apvts.getRawParameterValue ("delay")->load() / 100.0f;
    s.volume      = apvts.getRawParameterValue ("volume")->load() / 100.0f;
    s.width       = apvts.getRawParameterValue ("width")->load() / 100.0f;

    rendering = true;
    const double sr = currentRate.load();
    auto out = std::make_shared<juce::AudioBuffer<float>> (riser::render (src, srcRate, sr, s));
    const int riserLen = juce::jmin (out->getNumSamples(), juce::jmax (1, (int) (s.lengthSec * sr)));
    {
        const juce::SpinLock::ScopedLockType sl (renderedLock);
        rendered = out;
        renderedRiserLen = riserLen;
    }
    rendering = false;
}

// ---------------------------------------------------------------- audio

void ReverseRiserProcessor::renderRange (juce::AudioBuffer<float>& out, const juce::AudioBuffer<float>* src,
                                         int start, int end)
{
    if (! playing || src == nullptr || end <= start) return;

    const int available = src->getNumSamples() - playPos;
    const int n = juce::jmin (end - start, available);
    if (n <= 0) { playing = false; return; }

    const int chans = juce::jmin (out.getNumChannels(), src->getNumChannels());
    for (int c = 0; c < chans; ++c)
        out.addFrom (c, start, *src, c, playPos, n);

    playPos += n;
    if (playPos >= src->getNumSamples()) playing = false;
}

void ReverseRiserProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    std::shared_ptr<const juce::AudioBuffer<float>> buf;
    {
        const juce::SpinLock::ScopedLockType sl (renderedLock);
        buf = rendered;
    }

    int pos = 0;
    for (const auto meta : midi)
    {
        const auto msg = meta.getMessage();
        const int t = juce::jlimit (0, buffer.getNumSamples(), meta.samplePosition);
        renderRange (buffer, buf.get(), pos, t);
        pos = t;

        if (msg.isNoteOn())
        {
            playPos = 0;
            playing = (buf != nullptr);
        }
        else if (msg.isAllNotesOff() || msg.isAllSoundOff())
        {
            playing = false;
        }
    }
    renderRange (buffer, buf.get(), pos, buffer.getNumSamples());
}

// ---------------------------------------------------------------- sample / export

bool ReverseRiserProcessor::loadSample (const juce::File& file)
{
    juce::AudioFormatManager fm;
    fm.registerBasicFormats();
    std::unique_ptr<juce::AudioFormatReader> reader (fm.createReaderFor (file));
    if (reader == nullptr || reader->lengthInSamples <= 0) return false;

    const int chans = (int) juce::jmin ((unsigned int) 2, reader->numChannels);
    const int len = (int) juce::jmin ((juce::int64) (reader->sampleRate * 120.0), reader->lengthInSamples);

    juce::AudioBuffer<float> tmp (chans, len);
    reader->read (&tmp, 0, len, 0, true, chans > 1);

    {
        const juce::ScopedLock sl (sourceLock);
        sourceSample = std::move (tmp);
        sourceRate = reader->sampleRate;
        samplePath = file.getFullPathName();
    }
    dirty = true;
    return true;
}

bool ReverseRiserProcessor::hasSample() const
{
    const juce::ScopedLock sl (sourceLock);
    return sourceSample.getNumSamples() > 0;
}

juce::String ReverseRiserProcessor::getSampleName() const
{
    const juce::ScopedLock sl (sourceLock);
    return juce::File (samplePath).getFileName();
}

bool ReverseRiserProcessor::exportRendered (const juce::File& dest)
{
    std::shared_ptr<const juce::AudioBuffer<float>> buf;
    int riserLen = 0;
    {
        const juce::SpinLock::ScopedLockType sl (renderedLock);
        buf = rendered;
        riserLen = renderedRiserLen;
    }
    if (buf == nullptr || riserLen <= 0) return false;
    riserLen = juce::jmin (riserLen, buf->getNumSamples());

    dest.deleteFile();
    auto stream = std::make_unique<juce::FileOutputStream> (dest);
    if (! stream->openedOk()) return false;

    juce::WavAudioFormat wav;
    std::unique_ptr<juce::AudioFormatWriter> writer (
        wav.createWriterFor (stream.get(), currentRate.load(), 2, 24, {}, 0));
    if (writer == nullptr) return false;
    stream.release();   // le writer en prend la propriete

    return writer->writeFromAudioSampleBuffer (*buf, 0, riserLen);   // riser seul, sans le sample
}

juce::File ReverseRiserProcessor::exportToTemp()
{
    auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("ReverseRiser");
    dir.createDirectory();
    auto stem = juce::File (getSampleName()).getFileNameWithoutExtension();
    if (stem.isEmpty()) stem = "riser";
    auto f = dir.getChildFile (stem + "_riser.wav");
    return exportRendered (f) ? f : juce::File();
}

// ---------------------------------------------------------------- etat du projet

void ReverseRiserProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto xml = apvts.copyState().createXml();
    if (xml == nullptr) return;
    {
        const juce::ScopedLock sl (sourceLock);
        xml->setAttribute ("samplePath", samplePath);
    }
    copyXmlToBinary (*xml, destData);
}

void ReverseRiserProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
    {
        if (xml->hasTagName (apvts.state.getType()))
        {
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
            const auto path = xml->getStringAttribute ("samplePath");
            if (path.isNotEmpty() && juce::File (path).existsAsFile())
                loadSample (juce::File (path));
            dirty = true;
        }
    }
}

juce::AudioProcessorEditor* ReverseRiserProcessor::createEditor()
{
    return new ReverseRiserEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ReverseRiserProcessor();
}
