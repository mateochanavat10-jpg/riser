#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"

// Petit bloc a glisser vers la piste de FL Studio : exporte le WAV puis lance un drag & drop externe
class DragHandle : public juce::Component
{
public:
    DragHandle() { setMouseCursor (juce::MouseCursor::DraggingHandCursor); }

    std::function<juce::File()> makeFile;

    void paint (juce::Graphics& g) override
    {
        auto b = getLocalBounds().toFloat();
        g.setColour (juce::Colour (0xff3a6ea5));
        g.fillRoundedRectangle (b, 6.0f);
        g.setColour (juce::Colours::white);
        g.setFont (14.0f);
        g.drawText ("Glisse le riser vers la playlist", getLocalBounds(), juce::Justification::centred);
    }

    void mouseDrag (const juce::MouseEvent& e) override
    {
        if (dragging || e.getDistanceFromDragStart() < 8 || ! makeFile) return;
        dragging = true;
        const auto f = makeFile();
        if (f.existsAsFile())
            juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
        dragging = false;
    }

private:
    bool dragging = false;
};

class ReverseRiserEditor : public juce::AudioProcessorEditor,
                           public juce::FileDragAndDropTarget,
                           private juce::Timer
{
public:
    explicit ReverseRiserEditor (ReverseRiserProcessor&);
    ~ReverseRiserEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    bool isInterestedInFileDrag (const juce::StringArray& files) override;
    void filesDropped (const juce::StringArray& files, int x, int y) override;

private:
    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att;
    };

    void setupKnob (Knob& k, const juce::String& id, const juce::String& name,
                    const juce::String& suffix, int decimals);
    void timerCallback() override;
    void chooseFile();

    ReverseRiserProcessor& proc;

    juce::Label fileLabel, statusLabel, reverbLabel;
    juce::TextButton loadButton { "Charger un WAV" };
    juce::TextButton exportButton { "Exporter riser" };
    DragHandle dragHandle;

    Knob lengthKnob, delayKnob, volumeKnob, widthKnob;
    juce::ComboBox reverbBox;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> reverbAtt;

    std::unique_ptr<juce::FileChooser> chooser;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ReverseRiserEditor)
};
