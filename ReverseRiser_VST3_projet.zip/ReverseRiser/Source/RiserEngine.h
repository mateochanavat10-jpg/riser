#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <cmath>
#include <complex>
#include <random>
#include <vector>

// Moteur de rendu "hors temps reel" : calcule  [riser inverse] + [sample original]
namespace riser
{
struct Settings
{
    float lengthSec   = 4.0f;  // 1 .. 10 s
    int   reverbType  = 1;     // 0 Room, 1 Hall, 2 Plate, 3 Cathedral, 4 Dark
    float delayAmount = 0.4f;  // 0 .. 1
    float volume      = 0.8f;  // 0.1 .. 1.5 (x le pic du sample)
    float width       = 1.0f;  // 0 (mono) .. 2 (tres large)
};

struct ReverbShape
{
    float rtScale;   // multiplie la duree de decroissance
    float lpStart;   // coefficient du filtre passe-bas au debut (haut = plus sombre)
    float lpEnd;     // ... a la fin de la queue
    float preDelay;  // secondes
    float attack;    // secondes (montee de la reponse)
};

inline ReverbShape shapeFor (int type)
{
    switch (type)
    {
        case 0:  return { 0.60f, 0.30f, 0.70f, 0.000f, 0.004f }; // Room
        case 1:  return { 1.00f, 0.55f, 0.95f, 0.000f, 0.010f }; // Hall
        case 2:  return { 0.85f, 0.10f, 0.60f, 0.000f, 0.002f }; // Plate (brillante)
        case 3:  return { 1.20f, 0.60f, 0.97f, 0.035f, 0.030f }; // Cathedral
        default: return { 1.00f, 0.85f, 0.985f, 0.020f, 0.050f }; // Dark
    }
}

// FFT radix-2 iterative (double precision), taille = puissance de 2
inline void fft (std::vector<std::complex<double>>& x, bool inverse)
{
    const size_t n = x.size();
    for (size_t i = 1, j = 0; i < n; ++i)
    {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap (x[i], x[j]);
    }
    for (size_t len = 2; len <= n; len <<= 1)
    {
        const double ang = 2.0 * juce::MathConstants<double>::pi / (double) len * (inverse ? 1.0 : -1.0);
        const std::complex<double> wlen (std::cos (ang), std::sin (ang));
        for (size_t i = 0; i < n; i += len)
        {
            std::complex<double> w (1.0, 0.0);
            for (size_t k = 0; k < len / 2; ++k)
            {
                const auto u = x[i + k];
                const auto v = x[i + k + len / 2] * w;
                x[i + k] = u + v;
                x[i + k + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
    if (inverse)
        for (auto& v : x) v /= (double) n;
}

inline std::vector<float> fftConvolve (const std::vector<float>& a, const std::vector<float>& b)
{
    if (a.empty() || b.empty()) return {};
    const size_t outLen = a.size() + b.size() - 1;
    size_t n = 1;
    while (n < outLen) n <<= 1;

    std::vector<std::complex<double>> fa (n), fb (n);
    for (size_t i = 0; i < a.size(); ++i) fa[i] = (double) a[i];
    for (size_t i = 0; i < b.size(); ++i) fb[i] = (double) b[i];
    fft (fa, false);
    fft (fb, false);
    for (size_t i = 0; i < n; ++i) fa[i] *= fb[i];
    fft (fa, true);

    std::vector<float> out (outLen);
    for (size_t i = 0; i < outLen; ++i) out[i] = (float) fa[i].real();
    return out;
}

// Reponse impulsionnelle synthetique : bruit a decroissance exponentielle, de plus en plus sombre
inline std::vector<float> makeIR (double sr, double lengthSec, double rt60, const ReverbShape& s, unsigned seed)
{
    const int n = juce::jmax (16, (int) (sr * lengthSec));
    std::vector<float> ir ((size_t) n, 0.0f);
    std::mt19937 rng (seed);
    std::normal_distribution<float> dist (0.0f, 1.0f);

    const int pre = (int) (s.preDelay * sr);
    const int att = juce::jmax (1, (int) (s.attack * sr));
    float y = 0.0f;
    double energy = 0.0;

    for (int i = 0; i < n; ++i)
    {
        const double t = (double) i / sr;
        const float env = (float) std::exp (-6.9078 * t / rt60);
        const float a = s.lpStart + (s.lpEnd - s.lpStart) * ((float) i / (float) n);
        y = a * y + (1.0f - a) * dist (rng);
        float v = y * env;
        if (i < pre)             v = 0.0f;
        else if (i - pre < att)  v *= (float) (i - pre) / (float) att;
        ir[(size_t) i] = v;
        energy += (double) v * (double) v;
    }
    const float g = energy > 1e-12 ? (float) (1.0 / std::sqrt (energy)) : 1.0f;
    for (auto& v : ir) v *= g;
    return ir;
}

// Delay avec feedback, uniquement la partie "wet" (repetitions), sans le signal sec
inline std::vector<float> makeDelay (const std::vector<float>& seg, double sr, double timeSec,
                                     float feedback, int totalLen)
{
    std::vector<float> wet ((size_t) totalLen, 0.0f);
    const int d = juce::jmax (1, (int) (timeSec * sr));
    float gain = feedback;
    for (int tap = 1; (long long) tap * d < totalLen && gain > 0.01f; ++tap, gain *= feedback)
    {
        const int off = tap * d;
        const int n = juce::jmin ((int) seg.size(), totalLen - off);
        for (int i = 0; i < n; ++i)
            wet[(size_t) (off + i)] += seg[(size_t) i] * gain;
    }
    return wet;
}

inline juce::AudioBuffer<float> toStereoAtRate (const juce::AudioBuffer<float>& src, double srcRate, double dstRate)
{
    const int inN = src.getNumSamples();
    const bool same = std::abs (srcRate - dstRate) < 1.0e-6;
    const int outN = same ? inN : (int) std::floor ((double) inN * dstRate / srcRate);
    juce::AudioBuffer<float> out (2, juce::jmax (outN, 0));
    out.clear();
    if (inN == 0 || outN <= 0 || src.getNumChannels() == 0) return out;

    for (int c = 0; c < 2; ++c)
    {
        const float* in = src.getReadPointer (juce::jmin (c, src.getNumChannels() - 1));
        if (same)
        {
            out.copyFrom (c, 0, in, inN);
        }
        else
        {
            std::vector<float> padded ((size_t) inN + 16, 0.0f);   // evite de lire hors du tableau
            std::copy (in, in + inN, padded.begin());
            juce::LagrangeInterpolator li;
            li.process (srcRate / dstRate, padded.data(), out.getWritePointer (c), outN);
        }
    }
    return out;
}

inline juce::AudioBuffer<float> render (const juce::AudioBuffer<float>& source, double srcRate,
                                        double sr, const Settings& s)
{
    auto sample = toStereoAtRate (source, srcRate, sr);
    const int sampleLen = sample.getNumSamples();
    if (sampleLen < 2) return sample;

    const int wetLen = juce::jmax (1, (int) (s.lengthSec * sr));
    const int segLen = juce::jmin (sampleLen, (int) sr);          // 1re seconde du sample
    const auto shape = shapeFor (s.reverbType);
    const double rt60 = juce::jmax (0.3, ((double) s.lengthSec - 1.0) * (double) shape.rtScale);

    juce::AudioBuffer<float> riserBuf (2, wetLen);
    riserBuf.clear();

    std::vector<float> seg ((size_t) segLen);
    for (int c = 0; c < 2; ++c)
    {
        const float* in = sample.getReadPointer (c);
        for (int i = 0; i < segLen; ++i) seg[(size_t) i] = in[i];

        const int f = juce::jmin (segLen, (int) (0.005 * sr));     // petit fondu pour eviter un clic
        for (int i = 0; i < f; ++i)
            seg[(size_t) (segLen - f + i)] *= (float) (f - i) / (float) f;

        const auto ir  = makeIR (sr, (double) s.lengthSec, rt60, shape, 42u + (unsigned) c);
        const auto rev = fftConvolve (seg, ir);
        const auto dly = makeDelay (seg, sr, 0.375, 0.5f, wetLen);

        const float delayWeight = 0.8f * s.delayAmount;
        float* w = riserBuf.getWritePointer (c);
        for (int i = 0; i < wetLen; ++i)
        {
            const float r = (size_t) i < rev.size() ? rev[(size_t) i] : 0.0f;
            const float d = dly[(size_t) i];
            w[wetLen - 1 - i] = r + delayWeight * d;               // REVERSE
        }
    }

    // Largeur stereo (Mid/Side) : 0 = mono, 1 = naturel, 2 = tres large
    float* L = riserBuf.getWritePointer (0);
    float* R = riserBuf.getWritePointer (1);
    for (int i = 0; i < wetLen; ++i)
    {
        const float m  = 0.5f * (L[i] + R[i]);
        const float sd = 0.5f * (L[i] - R[i]) * s.width;
        L[i] = m + sd;
        R[i] = m - sd;
    }

    // Volume : pic du riser = volume x pic du sample original
    const float riserPeak  = riserBuf.getMagnitude (0, wetLen);
    const float samplePeak = sample.getMagnitude (0, sampleLen);
    riserBuf.applyGain (riserPeak > 1.0e-9f ? s.volume * samplePeak / riserPeak : 0.0f);

    juce::AudioBuffer<float> out (2, wetLen + sampleLen);
    for (int c = 0; c < 2; ++c)
    {
        out.copyFrom (c, 0, riserBuf, c, 0, wetLen);
        out.copyFrom (c, wetLen, sample, c, 0, sampleLen);
    }
    return out;
}
} // namespace riser
